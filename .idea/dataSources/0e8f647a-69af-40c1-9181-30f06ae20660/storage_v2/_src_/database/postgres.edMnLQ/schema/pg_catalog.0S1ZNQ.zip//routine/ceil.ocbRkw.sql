create function ceil(double precision) returns double precision
    language internal
as
$$dceil$$;

comment on function ceil(numeric) is 'nearest integer >= value';

