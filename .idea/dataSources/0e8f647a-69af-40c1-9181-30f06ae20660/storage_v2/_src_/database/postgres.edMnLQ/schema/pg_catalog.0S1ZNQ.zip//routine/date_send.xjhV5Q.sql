create function date_send(date) returns bytea
    language internal
as
$$date_send$$;

comment on function date_send(date) is 'I/O';

