create function bool_anytrue(internal) returns boolean
    language internal
as
$$bool_anytrue$$;

comment on function bool_anytrue(internal) is 'aggregate final function';

