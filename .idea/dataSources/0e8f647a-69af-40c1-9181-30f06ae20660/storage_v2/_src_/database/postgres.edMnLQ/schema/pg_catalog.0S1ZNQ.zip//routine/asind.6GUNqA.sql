create function asind(double precision) returns double precision
    language internal
as
$$dasind$$;

comment on function asind(float8) is 'arcsine, degrees';

