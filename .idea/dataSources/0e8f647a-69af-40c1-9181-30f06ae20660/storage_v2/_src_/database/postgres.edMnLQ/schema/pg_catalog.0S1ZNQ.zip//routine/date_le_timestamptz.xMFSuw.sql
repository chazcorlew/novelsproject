create function date_le_timestamptz(date, timestamp with time zone) returns boolean
    language internal
as
$$date_le_timestamptz$$;

comment on function date_le_timestamptz(date, timestamptz) is 'implementation of <= operator';

