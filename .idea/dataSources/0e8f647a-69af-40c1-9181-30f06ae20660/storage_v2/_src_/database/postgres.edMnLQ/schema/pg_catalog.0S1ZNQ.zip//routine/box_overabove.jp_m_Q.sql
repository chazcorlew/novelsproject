create function box_overabove(box, box) returns boolean
    language internal
as
$$box_overabove$$;

comment on function box_overabove(box, box) is 'implementation of |&> operator';

