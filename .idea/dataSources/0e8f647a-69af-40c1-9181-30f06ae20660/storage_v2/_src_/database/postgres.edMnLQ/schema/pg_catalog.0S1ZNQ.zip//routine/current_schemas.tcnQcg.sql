create function current_schemas(boolean) returns name[]
    language internal
as
$$current_schemas$$;

comment on function current_schemas(bool) is 'current schema search list';

