create function anycompatiblearray_recv(internal) returns anycompatiblearray
    language internal
as
$$anycompatiblearray_recv$$;

comment on function anycompatiblearray_recv(internal) is 'I/O';

