create function cstring_send(cstring) returns bytea
    language internal
as
$$cstring_send$$;

comment on function cstring_send(cstring) is 'I/O';

