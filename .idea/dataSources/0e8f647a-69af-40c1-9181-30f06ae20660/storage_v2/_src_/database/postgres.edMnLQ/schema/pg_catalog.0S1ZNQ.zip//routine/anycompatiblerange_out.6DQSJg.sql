create function anycompatiblerange_out(anycompatiblerange) returns cstring
    language internal
as
$$anycompatiblerange_out$$;

comment on function anycompatiblerange_out(anycompatiblerange) is 'I/O';

