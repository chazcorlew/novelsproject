create function date_pl_interval(date, interval) returns timestamp without time zone
    language internal
as
$$date_pl_interval$$;

comment on function date_pl_interval(date, interval) is 'implementation of + operator';

