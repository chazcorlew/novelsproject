create function date_ge_timestamp(date, timestamp without time zone) returns boolean
    language internal
as
$$date_ge_timestamp$$;

comment on function date_ge_timestamp(date, timestamp) is 'implementation of >= operator';

