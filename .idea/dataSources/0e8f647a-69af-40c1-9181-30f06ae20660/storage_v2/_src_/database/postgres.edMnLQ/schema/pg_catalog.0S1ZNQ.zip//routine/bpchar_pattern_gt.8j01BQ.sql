create function bpchar_pattern_gt(character, character) returns boolean
    language internal
as
$$bpchar_pattern_gt$$;

comment on function bpchar_pattern_gt(bpchar, bpchar) is 'implementation of ~>~ operator';

