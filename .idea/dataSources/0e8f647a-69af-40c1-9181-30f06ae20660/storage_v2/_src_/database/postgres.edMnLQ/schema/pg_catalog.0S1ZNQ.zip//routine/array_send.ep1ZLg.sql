create function array_send(anyarray) returns bytea
    language internal
as
$$array_send$$;

comment on function array_send(anyarray) is 'I/O';

