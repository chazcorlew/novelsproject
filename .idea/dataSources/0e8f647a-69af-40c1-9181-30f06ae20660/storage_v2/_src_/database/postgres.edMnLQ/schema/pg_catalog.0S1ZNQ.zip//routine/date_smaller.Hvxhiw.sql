create function date_smaller(date, date) returns date
    language internal
as
$$date_smaller$$;

comment on function date_smaller(date, date) is 'smaller of two';

