create function anyelement_in(cstring) returns anyelement
    language internal
as
$$anyelement_in$$;

comment on function anyelement_in(cstring) is 'I/O';

