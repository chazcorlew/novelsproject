create function daterange(date, date) returns daterange
    language internal
as
$$range_constructor2$$;

comment on function daterange(date, date) is 'daterange constructor';

