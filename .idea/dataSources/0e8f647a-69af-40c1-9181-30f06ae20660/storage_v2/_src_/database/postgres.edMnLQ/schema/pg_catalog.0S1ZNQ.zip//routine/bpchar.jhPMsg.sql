create function bpchar(name) returns character
    language internal
as
$$name_bpchar$$;

comment on function bpchar(name) is 'convert name to char(n)';

