create function date_in(cstring) returns date
    language internal
as
$$date_in$$;

comment on function date_in(cstring) is 'I/O';

