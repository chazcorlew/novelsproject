create function date_part(text, timestamp with time zone) returns double precision
    language internal
as
$$timestamptz_part$$;

comment on function date_part(text, interval) is 'extract field from interval';

