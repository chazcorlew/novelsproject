create function date_trunc(text, timestamp with time zone) returns timestamp with time zone
    language internal
as
$$timestamptz_trunc$$;

comment on function date_trunc(text, interval) is 'truncate interval to specified units';

