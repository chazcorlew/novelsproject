create function btoidcmp(oid, oid) returns integer
    language internal
as
$$btoidcmp$$;

comment on function btoidcmp(oid, oid) is 'less-equal-greater';

