create function close_ls(line, lseg) returns point
    language internal
as
$$close_ls$$;

comment on function close_ls(line, lseg) is 'implementation of ## operator';

