create function date_gt_timestamptz(date, timestamp with time zone) returns boolean
    language internal
as
$$date_gt_timestamptz$$;

comment on function date_gt_timestamptz(date, timestamptz) is 'implementation of > operator';

