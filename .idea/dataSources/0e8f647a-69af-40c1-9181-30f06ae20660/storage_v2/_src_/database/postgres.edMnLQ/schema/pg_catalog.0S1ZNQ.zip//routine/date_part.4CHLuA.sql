create function date_part(text, timestamp with time zone) returns double precision
    language internal
as
$$timestamptz_part$$;

comment on function date_part(text, timestamptz) is 'extract field from timestamp with time zone';

