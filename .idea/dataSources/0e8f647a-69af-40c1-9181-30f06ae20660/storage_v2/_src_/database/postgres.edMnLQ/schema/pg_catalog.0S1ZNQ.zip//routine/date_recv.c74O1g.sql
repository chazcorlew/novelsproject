create function date_recv(internal) returns date
    language internal
as
$$date_recv$$;

comment on function date_recv(internal) is 'I/O';

