create function date_pli(date, integer) returns date
    language internal
as
$$date_pli$$;

comment on function date_pli(date, int4) is 'implementation of + operator';

