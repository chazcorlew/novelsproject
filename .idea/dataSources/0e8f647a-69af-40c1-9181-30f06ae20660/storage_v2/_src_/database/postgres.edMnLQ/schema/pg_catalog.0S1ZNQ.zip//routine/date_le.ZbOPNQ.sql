create function date_le(date, date) returns boolean
    language internal
as
$$date_le$$;

comment on function date_le(date, date) is 'implementation of <= operator';

