create function date_sortsupport(internal) returns void
    language internal
as
$$date_sortsupport$$;

comment on function date_sortsupport(internal) is 'sort support';

