create function charin(cstring) returns "char"
    language internal
as
$$charin$$;

comment on function charin(cstring) is 'I/O';

