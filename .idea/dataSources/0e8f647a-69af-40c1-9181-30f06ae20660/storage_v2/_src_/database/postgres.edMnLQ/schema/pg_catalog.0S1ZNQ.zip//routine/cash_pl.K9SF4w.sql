create function cash_pl(money, money) returns money
    language internal
as
$$cash_pl$$;

comment on function cash_pl(money, money) is 'implementation of + operator';

