create function btfloat84cmp(double precision, real) returns integer
    language internal
as
$$btfloat84cmp$$;

comment on function btfloat84cmp(float8, float4) is 'less-equal-greater';

